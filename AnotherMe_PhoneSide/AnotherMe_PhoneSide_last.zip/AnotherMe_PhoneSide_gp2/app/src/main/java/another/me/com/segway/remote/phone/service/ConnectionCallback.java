package another.me.com.segway.remote.phone.service;



public interface ConnectionCallback {

    void onConnected();
    void onDisconnected();
}
